﻿using System;
using System.IO;
using Newtonsoft.Json;
using System.Text;
using System.Collections.Generic;

namespace Week2_Assignment
{
    // collection to store the data of doctors
    class DoctorList
    {
        public List<DoctorData> Doctors { get; set; }
    }

    class DoctorData
    {
        // details of the doctor

       
        public string RegistrationNo { get; set; }
        public string ContactNo { get; set; }
        public string ClinicTimings { get; set; }
        public string DoctorName { get; set; }
        public string Specialisation { get; set; }
        public string ClinicAddress { get; set; }
        public string City { get; set; }


        // function to get the data of the doctor
        public void getData()
        {
            Console.WriteLine("Please enter 7 digit Doctor Registration Number");
            RegistrationNo =Console.ReadLine();
            Console.WriteLine("Please enter Doctor Name");
            DoctorName = Console.ReadLine();
            Console.WriteLine("Please enter specialisation of doctor");
            Specialisation = Console.ReadLine();
            Console.WriteLine("Please enter 10 digit Doctor Contact Number");
            ContactNo = Console.ReadLine();
            Console.WriteLine("Please enter the Clinic Timings");
            ClinicTimings = Console.ReadLine();
            Console.WriteLine("Please enter the Clinic Address");
            ClinicAddress = Console.ReadLine();
            Console.WriteLine("Please enter the Clinic City");
            City = Console.ReadLine();

        }
        public void writeInFile(DoctorList list)
        {
            var jsonString = JsonConvert.SerializeObject(list);
            string filePath = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName + @"\Files\doctorlist.txt";
            File.WriteAllText(filePath, jsonString);
        }
        public DoctorList ReadFile()
        {
            string filePath = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName + @"\Files\doctorlist.txt";
            string readText = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<DoctorList>(readText);
        }

    }
    class Program
    { 
        static void Main(string[] args)
        {
            bool Flag = true;
            int choice;
            DoctorData doctor1 = new DoctorData();
            List<DoctorData> docdata =
                doctor1.ReadFile() == null ? new List<DoctorData>() : doctor1.ReadFile().Doctors;
            DoctorList doclist = new DoctorList();
            while (Flag)
            {
                Console.WriteLine("Please enter a choice from below list :-");
                Console.WriteLine(" 1.Add details to list \n 2. Show doctor's list \n 3.Exit ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        DoctorData doctor = new DoctorData();
                        doctor.getData();
                        docdata.Add(doctor);

                        doclist.Doctors = docdata;

                        doctor.writeInFile(doclist);
                        break;
                    
                    case 2:
                        foreach (var item in docdata)
                        {
                            Console.WriteLine(item.RegistrationNo);
                            Console.WriteLine(item.DoctorName);
                            Console.WriteLine(item.ContactNo);
                            Console.WriteLine(item.Specialisation);
                            Console.WriteLine(item.ClinicTimings);
                            Console.WriteLine(item.ClinicAddress);
                            Console.WriteLine(item.City);
                        }
                        break;
                    case 3:
                        Flag = false;
                        break;
                }
                if (!Flag)
                {
                    break;
                }
            }
        }
    }
}
